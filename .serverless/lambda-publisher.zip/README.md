# cw_lambda_publisher
Implementation of 2 Lambda functions: one to publish custom metric in CW &amp; another to get custom metrics and calculate advanced statistics for scaling
